chrome.commands.onCommand.addListener(function (command) {
    if (command === "getAnswer") {
        try {
            chrome.tabs.captureVisibleTab(async (screenshotData) => {
                if (!screenshotData) {
                    console.log("screenshotData is empty");
                    return;
                }

                await chrome.action.setBadgeText({
                    text: "...",
                })

                fetch('https://api.tolyan.me/express/api/gpt/getAnswer', {
                    mode: 'cors',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        image: screenshotData
                    })
                })
                    .then(response => response.json())
                    .then(data => {
                        console.log(data);
                        chrome.action.setBadgeText({
                            text: data.choices[0].message.content,
                        });

                    })
                    .catch(error => {
                        console.error('Error:', error)
                        chrome.action.setBadgeText({
                            text: "-",
                        });
                    });
            });
        } catch (e) {
            console.log(e);
        }
    } else if (command === "clearAnswer") {
        console.log("clearAnswer");
        clearBadge()
    }
});

chrome.runtime.onInstalled.addListener(() => {
    clearBadge();
});

function clearBadge() {
    chrome.action.setBadgeText({
        text: "0",
    });
}

