document.documentElement.addEventListener("keyup", function(e) {
    console.log(e.key)
});